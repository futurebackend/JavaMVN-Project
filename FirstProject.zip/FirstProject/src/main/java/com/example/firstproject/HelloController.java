package com.example.firstproject;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("C# is better");
    }
    @FXML
    protected void onHelloButtonClick2() {
        welcomeText.setText("Java is better");
    }
}